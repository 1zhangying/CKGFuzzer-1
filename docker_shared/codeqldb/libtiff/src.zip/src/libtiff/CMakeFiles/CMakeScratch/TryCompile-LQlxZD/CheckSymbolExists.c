/* */
#include <unistd.h>

int main(int argc, char** argv)
{
  (void)argv;
#ifndef setmode
  return ((int*)(&setmode))[argc];
#else
  (void)argc;
  return 0;
#endif
}
