/* */
#include <math.h>

int main(int argc, char** argv)
{
  (void)argv;
#ifndef pow
  return ((int*)(&pow))[argc];
#else
  (void)argc;
  return 0;
#endif
}
