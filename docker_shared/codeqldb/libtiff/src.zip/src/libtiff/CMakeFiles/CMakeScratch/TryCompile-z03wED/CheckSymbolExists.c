/* */
#include <getopt.h>

int main(int argc, char** argv)
{
  (void)argv;
#ifndef optarg
  return ((int*)(&optarg))[argc];
#else
  (void)argc;
  return 0;
#endif
}
