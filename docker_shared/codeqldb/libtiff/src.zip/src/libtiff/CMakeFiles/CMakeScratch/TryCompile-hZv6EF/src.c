
        #include <stddef.h>
        #include <stdio.h>
        #include "jpeglib.h"
        int main()
        {
            jpeg_read_scanlines(0,0,0);
            jpeg12_read_scanlines(0,0,0);
            return 0;
        }
        
