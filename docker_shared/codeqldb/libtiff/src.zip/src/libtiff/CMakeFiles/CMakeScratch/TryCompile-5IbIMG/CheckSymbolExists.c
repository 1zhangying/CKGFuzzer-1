/* */
#include <jbig.h>

int main(int argc, char** argv)
{
  (void)argv;
#ifndef jbg_newlen
  return ((int*)(&jbg_newlen))[argc];
#else
  (void)argc;
  return 0;
#endif
}
