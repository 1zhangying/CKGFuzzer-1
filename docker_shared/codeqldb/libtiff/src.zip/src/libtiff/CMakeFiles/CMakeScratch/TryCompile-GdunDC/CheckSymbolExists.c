/* */
#include <sys/mman.h>

int main(int argc, char** argv)
{
  (void)argv;
#ifndef mmap
  return ((int*)(&mmap))[argc];
#else
  (void)argc;
  return 0;
#endif
}
