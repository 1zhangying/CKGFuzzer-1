/* */
#include <unistd.h>
#include <stdio.h>

int main(int argc, char** argv)
{
  (void)argv;
#ifndef getopt
  return ((int*)(&getopt))[argc];
#else
  (void)argc;
  return 0;
#endif
}
