/* libtiff/libport_config.h.cmake.in.  Not generated, but originated from autoheader.  */
/* This file must be kept up-to-date with needed substitutions from port/libport_config.h.in. */

#ifndef _LIBPORT_CONFIG_H_
#define _LIBPORT_CONFIG_H_

/* Define to 1 if you have the `getopt' function. */
#define HAVE_GETOPT 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

#endif /* _LIBPORT_CONFIG_H_ */
