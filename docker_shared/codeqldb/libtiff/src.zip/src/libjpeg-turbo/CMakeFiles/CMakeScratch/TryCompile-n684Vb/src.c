extern const int table[1]; const int __attribute__((visibility("hidden"))) table[1] = { 0 }; int main(void) { return table[0]; }
