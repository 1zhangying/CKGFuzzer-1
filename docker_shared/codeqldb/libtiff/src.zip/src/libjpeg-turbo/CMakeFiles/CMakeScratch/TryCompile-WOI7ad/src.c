static __thread int i;  int main(void) { i = 0;  return i; }
