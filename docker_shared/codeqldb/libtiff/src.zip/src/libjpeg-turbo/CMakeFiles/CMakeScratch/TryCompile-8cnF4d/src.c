int main(int argc, char **argv) { unsigned long a = argc;  return __builtin_ctzl(a); }
