
    #if (__CET__ & 3) == 0
    #error "CET not enabled"
    #endif
    int main(void) { return 0; }
