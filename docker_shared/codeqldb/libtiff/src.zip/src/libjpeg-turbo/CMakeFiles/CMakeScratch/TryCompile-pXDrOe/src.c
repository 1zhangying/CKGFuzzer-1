__inline__ __attribute__((always_inline)) static int foo(void) { return 0; } int main(void) { return foo(); }
